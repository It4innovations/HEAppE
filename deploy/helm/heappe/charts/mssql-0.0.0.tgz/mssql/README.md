# Helm chart for Microsoft SQL Server

Microsoft SQL Server is still used by many organizations. And migration to Cloud native can be a blocked by having this technology.
In order to help organization to lift-shift to Cloud Native, they can run also MS SQL in kubernetes via this Helm chart

> **DISCLAIMER**
> BY DEPLOYING THIS HELM CHART, YOU ARE ACCEPTING THE [END-USER Licensing Agreement of Microsoft SQL Server](https://github.com/microsoft/mssql-docker/blob/master/LICENSE)

## Install

Verify the helm chart via cosign

```sh
cosign verify registry.gitlab.com/xrow-public/helm-mssql/mssql:${CI_DOCUMENTATION_LATEST_TAG} --certificate-identity "https://gitlab.com/xrow-public/helm-mssql//.gitlab-ci.yml@refs/heads/main" --certificate-oidc-issuer "https://gitlab.com"
```

values.yaml
```yaml
---
global:
  storageClass: "managed-csi-premium" # Change this if needed

auth:
  database: test
  rootPassword: 'yourStrong(#)Password'
  username: test
  password: 'yourStrong(#)Password'
```

```sh
helm upgrade --install mssql oci://registry.gitlab.com/xrow-public/helm-mssql/charts/mssql --version ${CI_DOCUMENTATION_LATEST_TAG} --create-namespace -n mssql -f values.yaml
```

# values.yaml

Check default values of this chart [here](https://gitlab.com/xrow-public/helm-mssql/-/blob/main/chart/values.yaml) .

# Features

* Applying Helm Chart standards
* Ability to specify own registry
* Persisting data
* Auto Bootstrapping Database
* Auto Bootstraping Database Owner User with given password
* Ability to execute initial DB scripts (SQL)
* Replication architecture with separate primary and secondary StatefulSets and services
* Performance Monitoring - Integrated with Prometheus Operator

## Replication architecture

Set `architecture: replication` to deploy one primary StatefulSet and a configurable secondary StatefulSet.

```yaml
architecture: replication

auth:
  rootPassword: 'yourStrong(#)Password'
  replicationPassword: 'yourStrong(#)Password'

secondary:
  replicaCount: 2
```

The chart renders independent persistent volumes for primary and secondary pods, headless services for stable StatefulSet DNS, and separate client services:

* `<release>-mssql-primary` for primary connections
* `<release>-mssql-secondary` for secondary connections

## Data initalisation via init folder

```Docker
FROM registry.gitlab.com/xrow-public/helm-mssql:${CI_DOCUMENTATION_LATEST_TAG}

COPY *.sql /docker-entrypoint-initdb.d
```

## Test the container

```bash
podman build -t mssql .
docker run -e 'ACCEPT_EULA=Y' -e 'MSSQL_SA_PASSWORD=<YourStrong#Passw0rd>' -p 1433:1433 -v sqlvolume:/var/opt/mssql -it localhost/mssql:${CI_DOCUMENTATION_LATEST_TAG}
```

## Credits

Credits to [ElmCompany](https://github.com/ElmCompany/helm-charts/tree/master/charts/mssql) for inital work.
